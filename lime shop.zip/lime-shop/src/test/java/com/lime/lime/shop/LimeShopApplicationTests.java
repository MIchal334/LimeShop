package com.lime.lime.shop;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LimeShopApplicationTests {

	@Test
	void contextLoads() {
	}

}
