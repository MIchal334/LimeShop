package com.lime.lime.shop;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LimeShopApplication {

	public static void main(String[] args) {
		SpringApplication.run(LimeShopApplication.class, args);
	}

}
